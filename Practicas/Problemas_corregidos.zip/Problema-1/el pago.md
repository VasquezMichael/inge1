> **ID**: Pago de reserva de mobiliarios
>
> **TÍTULO**: **Como** usuario **quiero** efectuar pago **para poder** hacer la reserva de mobiliarios.
> 

> **CRITERIOS DE ACEPTACIÓN**: (Pagar con tarjeta)
> -  **Escenario 1**: Pago exitoso
> **Dado** que la conexión con el servidor del banco es exitosa, el número de tarjeta 1234 es válido y la tarjeta tiene saldo,
> **Cuando** el usuario ingresa el número de tarjeta 1234 y le da a "pagar",
> **Entonces** el sistema registra el pago. 
>
> - **Escenario 2**: Pago fallido por número de tarjeta inválido
> **Dado** que la conexión con el servidor del banco es exitosa y el número de tarjeta 1234 es inválido,
> **Cuando** el usuario le da a "pagar",
> **Entonces** el sistema informa que el numero de tarjeta es inválido y no realiza el pago. 
> 
> - **Escenario 3**: Pago fallido por saldo insuficiente de tarjeta de crédito 
> **Dado** que la conexión con el servidor del banco es exitosa, el número de tarjeta 1234 es válido y no tiene saldo,
> **Cuando** el usuario le da a "pagar",
> **Entonces** el sistema informa que el saldo es insuficiente y no se registra el pago. 
> 
> - **Escenario 4**: Pago fallido por fallo en conexión con el servidor externo del banco
> **Dado** que no se pudo realizar la conexión con el servidor del banco,
> **Cuando** el usuario "le da a pagar",
> **Entonces** el sistema informa que no se pudo establecer la conexión con el servidor del banco.

