> **ID**: Reservar mobiliarios
>
> **TÍTULO**: **Como** usuario **quiero** hacer una reserva **para poder** alquilar mobiliarios.
> 
> **REGLAS DE NEGOCIO**: 
> - Una reserva tiene que tener como mínimo 3 mobiliarios.
> - Se debe abonar el 20% del total del alquiler.
> - El pago se realiza únicamente con tarjeta de crédito.

> **CRITERIOS DE ACEPTACIÓN**: (Reservar mobiliarios)
> -  **Escenario 1**: Reserva de mobiliarios exitosa.
> **Dado** que el usuario selecciono al menos 3 mobiliarios,  ingresó la tarjeta "1234" la cual es válida y aceptó el pago del 20%,
> **Cuando** le da al boton de "reservar",
> **Entonces** el sistema efectua el pago y emite un número de reserva único. 
>
> - **Escenario 2**: Reserva fallida por mobiliarios insuficientes.
> **Dado** que el usuario seleccionó menos de 3 mobiliarios,  ingresó la tarjeta "1234" la cual es válida y aceptó el pago del 20%.
> **Cuando** le da al boton de "reservar",
> **Entonces** el sistema informa que no se seleccionó la cantidad de mobiliarios suficiente para realizar la reserva. 
> 
> - **Escenario 3**: Reserva fallida por problema de pago 
> **Dado** que el usuario selecciono al menos 3 mobiliarios,  ingresó la tarjeta "1234" la cual rechazó el pago del 20%,
> **Cuando** le da al boton de "reservar",
> **Entonces** el sistema informa que hay problemas con el pago.
> 
