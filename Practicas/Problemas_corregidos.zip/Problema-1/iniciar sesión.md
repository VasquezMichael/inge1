> **ID**: Iniciar sesion como encargado.
>
> **TÍTULO**: **Como** encargado **quiero** autentificarme en el sistema **para poder** dar de alta los diferentes mobiliarios.
> 

> > **CRITERIOS DE ACEPTACIÓN**: (inicio de sesion encargado)
> -  **Escenario 1**: 
> **Dado** que el encargado se encuentra registrado en el sistema,
> **Cuando** se aprieta el boton autentificar,
> **Entonces** el sistema le da acceso. 
>
> - **Escenario 2**: Autentificación fallida por usuario inválido
> **Dado** que el encargado no se encuentra registrado en el sistema,
> **Cuando** se aprieta el boton autentificar,
> **Entonces** el sistema informa que no está registrado. 
> 
