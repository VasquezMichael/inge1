> **ID:** Cerrar sesión.
>
> **TItulo: ** **Como** encargado **quiero** cerrar sesion **para poder** salir del sistema.
>
> **Reglas de negocio:**
>- Tiene que haber iniciado sesión


> **Criterios de aceptacion (Iniciar sesion):**
>- **Escenario 1: Cierre de sesión exitoso.**
> **Dado** que el usuario esta en una sesion activa,
> **Cuando** aprieta cerrar sesión,
> **Entonces** el sistema cierra sesión y va a la pantalla de login.


