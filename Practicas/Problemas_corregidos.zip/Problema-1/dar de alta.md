> **ID**: Dar de alta mobiliarios.
>
> **TÍTULO**: **Como** encargado **quiero** dar de alta mobiliarios **para poder** ingresarlos al sistema.
> 
> **REGLAS DE NEGOCIO**: 
> - No pueden existir códigos de mobiliarios repetidos 
>

> **CRITERIOS DE ACEPTACIÓN**: (Dar de alta)
> -  **Escenario 1**: Dar de alta con éxito
> **Dado** que el encargado ingresa código de inventario 123 que no se encuentra en el sistema , tipo de mueble untipo, fecha de creación 12/02/2000, fecha de último mantenimiento 12/02/2010, estado (libre, de baja, alquilado) y el precio de alquiler usd200,
> **Cuando** ingresa el codigo de inventario "123" y le da al boton "dar de alta",
> **Entonces** el sistema da de alta un mobiliario. 
>
> - **Escenario 2**: Alta fallida por código de inventario repetido
> **Dado** que el encargado ingresa código de inventario 123 que ya se encuentra en el sistema , tipo de mueble untipo, fecha de creación 12/02/2000, fecha de último mantenimiento 12/02/2010, estado (libre, de baja, alquilado) y el precio de alquiler usd200,
> **Cuando** ingresa el codigo de inventario "123" y le da al boton "dar de alta",
> **Entonces** el sistema informa que el código de inventario ya existe. 
> 
