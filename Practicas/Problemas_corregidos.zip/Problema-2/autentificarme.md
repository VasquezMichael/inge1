> **ID**: Autentificar empleado administrativo.
>
> **TÍTULO**: **Como** empleado administrativo **quiero** autentificarme en el sistema **para poder** cargar las carreras de grado de la Facultad de Informática.

> **CRITERIOS DE ACEPTACIÓN**: (Autentificar empleado administrativo)
> -  **Escenario 1**: 
> **Dado** que el empleado esta registrado en el sistema,
> **Cuando** le da a autentificar,
> **Entonces** el sistema le da acceso. 
>
> - **Escenario 2**: Autentificación fallida por usuario inválido
> **Dado** que el empleado no se encuentra registrado en el sistema,
> **Cuando** le da a autentificar,
> **Entonces** el sistema informa que el usuario no esta registrado. 


