> **ID:** Cerrar sesión.
>
> **TItulo: ** **Como** alumno **quiero** cerrar sesion en el sistema **para poder** salir del sistema.
>
> **Reglas de negocio:**
>- Tiene que haber iniciado sesion

> **CRITERIOS DE ACEPTACIÓN**: (Cierre exitoso)
>>- **Escenario 1: Cierre de sesión exitoso.**
> **Dado** que el alumno esta en una sesion activa,
> **Cuando** aprieta cerrar sesión,
> **Entonces** el sistema cierra sesión y vuelve a la pantalla de login.


